# -*- coding: utf-8 -*-
from . import scripts
from . import os0core

os0 = os0core.Os0(doinit=True)
