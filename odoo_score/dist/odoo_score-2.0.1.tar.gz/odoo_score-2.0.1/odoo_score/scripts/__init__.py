from . import main
# from . import run_odoo_debug
from . import rename_odoo_module
