from . import scripts
from . import _travis
from . import z0testlib

z0test = z0testlib.Z0test()
z0testodoo = z0testlib.Z0testOdoo()
