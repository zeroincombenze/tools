0.3.2.1 (2021-09-03)
~~~~~~~~~~~~~~~~~~~~

[IMP] lisa_bld: value from config file

0.3.1.14 (2021-07-21)
~~~~~~~~~~~~~~~~~~~~~

[FIX] lisa_bld: error for odoo 6.1 with server directory
