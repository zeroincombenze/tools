def get_environ_param(what, vid, repos=None, gitorg=None, options=None):
    pass
